package com.banco.exchangerate.service;

import com.banco.exchangerate.model.ExchangeRate;
import com.banco.exchangerate.repository.ExchangeRateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ExchangeRateService implements IExchangeRateService {
    @Autowired
    ExchangeRateRepository repository;

    @Override
    public Mono<ExchangeRate> create(ExchangeRate exchangeRate) {
        //client.setId(sequeenceId());
        return repository.save(exchangeRate);
    }

    @Override
    public Mono<ExchangeRate> findById(Integer id) {
        return repository.findById(id);
    }

    @Override
    public Flux<ExchangeRate> findAll() {
        Flux<ExchangeRate> c=repository.findAll();

        c.subscribe(p->System.out.println(p.getValueRate()));

        return repository.findAll();
    }

    @Override
    public Mono<ExchangeRate> findByDate(String dateExchange)
    {
        return repository.findAll().filter(x -> x.getDateExchange().equals(dateExchange)).last();
    }

    @Override
    public Mono<ExchangeRate> update(String dateExchange, Mono<ExchangeRate> exchangeRate) {

        return this.findByDate(dateExchange)
                .flatMap(p -> exchangeRate.map(u -> {
                    p.setId (u.getId());
                    p.setDateExchange(u.getDateExchange());
                    p.setValueRate(u.getValueRate());
                    return p;
                }))
                .flatMap(p -> this.repository.save(p));
    }

    @Override
    public Mono<Void> delete(Integer id) {
        return repository.deleteById(id);
    }


}

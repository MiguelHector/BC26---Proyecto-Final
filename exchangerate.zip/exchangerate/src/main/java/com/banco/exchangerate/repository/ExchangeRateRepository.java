package com.banco.exchangerate.repository;

import com.banco.exchangerate.model.ExchangeRate;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ExchangeRateRepository extends ReactiveMongoRepository<ExchangeRate, Integer> {
}
